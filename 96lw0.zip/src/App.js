import React from "react";
import "/public//styles.css";

import List from "/List";
function App() {
  return (
    <div>
      <div className="bg-image"></div>
      <div className="main">
        <div className="header">
          <h1>TODO</h1>
          <button type="button" name="button">
            <img className="image" src="images/icon-sun.svg" alt="" />
          </button>
        </div>
        <div className="todo-section">
          <List />
        </div>
        Drag and drop to reorder list
        <div className="attribution">
          Challenge by
          <a href="https://www.frontendmentor.io?ref=challenge" target="_blank">
            Frontend Mentor
          </a>
          . Coded by <a href="home">Ashraf sBen Moumou</a>.
        </div>
      </div>
    </div>
  );
}

export default App;
