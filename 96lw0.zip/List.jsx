import React, { useState } from "react";
import Form from "/Form";
import Item from "/Item";

export default function List() {
  const [todos, setTodos] = useState([
    {
      text: "Welcome",
      completed: false
    }
  ]);

  const addTodo = (todo) => {
    if (todo.text === "") {
      alert("Please enter a string");
    } else {
      setTodos((prevItems) => {
        return [todo, ...prevItems];
      });
    }
  };

  const toggleCompleted = (id) => {
    setTodos(
      todos.map((todo) => {
        if (todo.id === id) {
          return {
            id: todo.id,
            text: todo.text,
            completed: !todo.completed
          };
        } else {
          return todo;
        }
      })
    );
  };
  const [filter, setFilter] = useState("All");
  let newTodos = [];
  function filtering() {
    if (filter === "All") {
      newTodos = todos;
    }
    if (filter === "Active") {
      newTodos = todos.filter((todo) => !todo.completed);
    }
    if (filter === "Completed") {
      newTodos = todos.filter((todo) => todo.completed);
    }
  }
  const update = (s) => {
    setFilter(s);
  };
  filtering();

  const deleteTodo = (id) => {
    console.log(id);
    setTodos(todos.filter((todo) => todo.id !== id));
  };
  const deleteCompleted = () => {
    setTodos(todos.filter((todo) => todo.completed === false));
  };
  return (
    <div>
      <Form onSubmit={addTodo} />
      <div className="todo-list">
        {newTodos.map((todo) => (
          <Item
            key={todo.id}
            todo={todo}
            onDelete={() => {
              deleteTodo(todo.id);
            }}
            onComplete={() => {
              toggleCompleted(todo.id);
            }}
          />
        ))}
        <div className="bottom-items">
          <p>
            {todos.filter((todo) => todo.completed === false).length} items left
          </p>
          <div className="btns">
            <button
              onClick={() => {
                update("All");
              }}
              name="All"
            >
              All
            </button>
            <button
              onClick={() => {
                update("Active");
              }}
              name="Active"
            >
              Active
            </button>
            <button
              onClick={() => {
                update("Completed");
              }}
              name="Completed"
            >
              Completed
            </button>
          </div>
          <button onClick={deleteCompleted} name="Clear Completed">
            Clear Completed
          </button>
        </div>
      </div>
    </div>
  );
}
