import React from "react";

function Item(props) {
  return (
    <div className="todo-item">
      <div className="todo-text">
        <input
          onClick={props.onComplete}
          className="checkbox"
          type="checkbox"
          name=""
          value=""
        />
        <p
          style={{
            textDecoration: props.todo.completed ? "line-through" : "none"
          }}
        >
          {props.todo.text}
        </p>
      </div>
      <button onClick={props.onDelete}>X</button>
    </div>
  );
}
export default Item;
