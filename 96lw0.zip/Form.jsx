import React, { useState } from "react";
import shortid from "shortid";

export default function Form(props) {
  const [text, setText] = useState("");

  const handleChange = (e) => {
    const newInput = e.target.value;
    setText(newInput);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    props.onSubmit({
      id: shortid.generate(),
      text: text,
      completed: false
    });
    setText("");
  };
  return (
    <form>
      <input
        onChange={handleChange}
        className="main-input"
        type="text"
        name="text"
        value={text}
        placeholder="Todo..."
      />
      <button style={{ visibility: "hidden" }} onClick={handleSubmit}></button>
    </form>
  );
}
